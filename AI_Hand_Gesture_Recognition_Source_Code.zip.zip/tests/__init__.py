"""Automated logic tests; no webcam is required."""

