import unittest

from modules.landmark_processor import angle_degrees, process_landmarks


def neutral_landmarks():
    """Small synthetic 21-point fixture with all points in normalized space."""
    points = [{"x": 0.5, "y": 0.5, "z": 0.0} for _ in range(21)]
    points[0] = {"x": 0.5, "y": 0.8, "z": 0.0}
    for mcp, pip, tip, x in ((5, 6, 8, 0.35), (9, 10, 12, 0.45), (13, 14, 16, 0.55), (17, 18, 20, 0.65)):
        points[mcp] = {"x": x, "y": 0.58, "z": 0.0}
        points[pip] = {"x": x, "y": 0.66, "z": 0.0}
        points[tip] = {"x": x, "y": 0.72, "z": 0.0}
    points[2] = {"x": 0.47, "y": 0.65, "z": 0.0}
    points[3] = {"x": 0.43, "y": 0.67, "z": 0.0}
    points[4] = {"x": 0.39, "y": 0.68, "z": 0.0}
    return points


class LandmarkProcessorTests(unittest.TestCase):
    def test_returns_five_states_and_normalized_measurements(self):
        result = process_landmarks(neutral_landmarks())
        self.assertEqual(list(result["finger_states"]), ["thumb", "index", "middle", "ring", "pinky"])
        self.assertEqual(len(result["pattern"]), 5)
        self.assertGreater(result["measurements"]["palm_width_norm"], 0)
        self.assertIn("thumb_index_distance_palm_widths", result["measurements"])

    def test_rejects_wrong_landmark_count(self):
        with self.assertRaises(ValueError):
            process_landmarks([{"x": 0, "y": 0, "z": 0}] * 20)

    def test_angle_helper(self):
        a, b, c = ({"x": 1, "y": 0}, {"x": 0, "y": 0}, {"x": 0, "y": 1})
        self.assertAlmostEqual(angle_degrees(a, b, c), 90.0)


if __name__ == "__main__":
    unittest.main()

