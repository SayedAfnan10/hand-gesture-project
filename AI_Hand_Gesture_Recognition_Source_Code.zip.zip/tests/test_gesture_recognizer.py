import unittest

from modules.gesture_recognizer import recognize_gesture


def processed(pattern, thumb_distance=0.8, thumb_vertical=0.0):
    names = ("thumb", "index", "middle", "ring", "pinky")
    return {
        "finger_states": dict(zip(names, map(bool, pattern))),
        "pattern": list(pattern),
        "measurements": {
            "thumb_index_distance_palm_widths": thumb_distance,
            "thumb_vertical_offset_palm_heights": thumb_vertical,
        },
    }


class GestureRecognizerTests(unittest.TestCase):
    def test_fist_returns_structured_result(self):
        result = recognize_gesture(processed([0, 0, 0, 0, 0]))
        self.assertEqual(result["gesture"], "Fist")
        self.assertEqual(result["pattern"], [0, 0, 0, 0, 0])
        self.assertTrue(result["reasons"])
        self.assertIn("measurements", result)

    def test_peace_and_rock_patterns(self):
        self.assertEqual(recognize_gesture(processed([0, 1, 1, 0, 0]))["gesture"], "Peace / Victory")
        self.assertEqual(recognize_gesture(processed([0, 1, 0, 0, 1]))["gesture"], "Rock")

    def test_ok_requires_tip_proximity(self):
        near = recognize_gesture(processed([1, 1, 1, 1, 1], thumb_distance=0.2))
        far = recognize_gesture(processed([1, 1, 1, 1, 1], thumb_distance=0.8))
        self.assertEqual(near["gesture"], "OK")
        self.assertEqual(far["gesture"], "Open Palm")

    def test_thumb_direction(self):
        self.assertEqual(recognize_gesture(processed([1, 0, 0, 0, 0], thumb_vertical=0.5))["gesture"], "Thumbs Up")
        self.assertEqual(recognize_gesture(processed([1, 0, 0, 0, 0], thumb_vertical=-0.5))["gesture"], "Thumbs Down")


if __name__ == "__main__":
    unittest.main()

