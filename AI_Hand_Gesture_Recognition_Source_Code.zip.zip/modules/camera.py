"""Safe OpenCV webcam wrapper."""

import cv2


class Camera:
    """Open, read, and release a webcam without leaking the device."""

    def __init__(self, index=0, width=None, height=None):
        self.index = index
        self.width = width
        self.height = height
        self.capture = None

    def open(self):
        self.capture = cv2.VideoCapture(self.index, cv2.CAP_DSHOW) if hasattr(cv2, "CAP_DSHOW") else cv2.VideoCapture(self.index)
        if not self.capture.isOpened():
            self.release()
            raise RuntimeError(
                f"Could not open webcam {self.index}. Close other camera apps, "
                "check Windows camera permissions, or change CAMERA_INDEX in config.py."
            )
        if self.width:
            self.capture.set(cv2.CAP_PROP_FRAME_WIDTH, self.width)
        if self.height:
            self.capture.set(cv2.CAP_PROP_FRAME_HEIGHT, self.height)
        return self

    def read(self):
        """Return (success, frame); failure is reported without throwing."""
        if self.capture is None or not self.capture.isOpened():
            return False, None
        return self.capture.read()

    def release(self):
        if self.capture is not None:
            self.capture.release()
            self.capture = None

    def __enter__(self):
        return self.open()

    def __exit__(self, exc_type, exc_value, traceback):
        self.release()

