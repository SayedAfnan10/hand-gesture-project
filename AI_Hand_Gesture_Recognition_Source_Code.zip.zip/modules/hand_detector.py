"""MediaPipe Tasks hand landmark detection for webcam video frames."""

import cv2
import mediapipe as mp

from modules.utils import ensure_model


class HandDetector:
    """Detect up to N hands and return normalized 21-point landmarks."""

    def __init__(self, model_path, max_hands=2, detection_confidence=0.5,
                 presence_confidence=0.5, tracking_confidence=0.5):
        model_path = ensure_model(model_path)
        options = mp.tasks.vision.HandLandmarkerOptions(
            base_options=mp.tasks.BaseOptions(model_asset_path=str(model_path)),
            running_mode=mp.tasks.vision.RunningMode.VIDEO,
            num_hands=max_hands,
            min_hand_detection_confidence=detection_confidence,
            min_hand_presence_confidence=presence_confidence,
            min_tracking_confidence=tracking_confidence,
        )
        self.detector = mp.tasks.vision.HandLandmarker.create_from_options(options)
        self.last_timestamp_ms = -1

    def detect(self, frame_bgr, timestamp_ms=None):
        """Return one dictionary per hand; each has landmarks and handedness."""
        if timestamp_ms is None:
            timestamp_ms = self.last_timestamp_ms + 1
        timestamp_ms = max(int(timestamp_ms), self.last_timestamp_ms + 1)
        self.last_timestamp_ms = timestamp_ms
        rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
        result = self.detector.detect_for_video(image, timestamp_ms)
        hands = []
        for index, points in enumerate(result.hand_landmarks):
            landmarks = [{"x": float(p.x), "y": float(p.y), "z": float(p.z)} for p in points]
            category = result.handedness[index][0] if index < len(result.handedness) and result.handedness[index] else None
            hands.append({
                "landmarks": landmarks,
                "handedness": category.category_name if category else "Unknown",
                "handedness_score": float(category.score) if category else 0.0,
            })
        return hands

    def close(self):
        if self.detector is not None:
            self.detector.close()
            self.detector = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.close()

