"""Small shared helpers for model setup and coordinate conversion."""

from pathlib import Path
from urllib.request import urlretrieve

MODEL_URL = (
    "https://storage.googleapis.com/mediapipe-models/hand_landmarker/"
    "hand_landmarker/float16/1/hand_landmarker.task"
)


def ensure_model(model_path: str | Path) -> Path:
    """Return the model path, downloading the official task model if needed."""
    path = Path(model_path)
    if path.is_file():
        return path
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary_path = path.with_suffix(path.suffix + ".download")
    try:
        print(f"Downloading MediaPipe hand model to {path} ...")
        urlretrieve(MODEL_URL, temporary_path)
        temporary_path.replace(path)
    except Exception:
        temporary_path.unlink(missing_ok=True)
        raise RuntimeError(
            "Could not download the MediaPipe hand model. Check your internet "
            f"connection and download it manually from {MODEL_URL} to {path}."
        )
    return path


def normalized_distance(point_a: dict, point_b: dict) -> float:
    """Euclidean distance between normalized 2D landmark dictionaries."""
    dx = float(point_a["x"]) - float(point_b["x"])
    dy = float(point_a["y"]) - float(point_b["y"])
    return (dx * dx + dy * dy) ** 0.5

