"""Reusable modules for the hand gesture recognition application."""

