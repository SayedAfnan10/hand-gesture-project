"""Drawing and rendering for the live camera window."""

import cv2

HAND_CONNECTIONS = (
    (0, 1), (1, 2), (2, 3), (3, 4), (0, 5), (5, 6), (6, 7), (7, 8),
    (5, 9), (9, 10), (10, 11), (11, 12), (9, 13), (13, 14), (14, 15),
    (15, 16), (13, 17), (17, 18), (18, 19), (19, 20), (0, 17),
)


class CameraDisplay:
    def __init__(self, window_name, width, height, x=20, y=40):
        self.window_name = window_name
        cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(window_name, width, height)
        cv2.moveWindow(window_name, x, y)

    def render(self, frame, hands, recognition, fps):
        canvas = frame.copy()
        h, w = canvas.shape[:2]
        for hand in hands:
            points = hand["landmarks"]
            pixels = [(int(p["x"] * w), int(p["y"] * h)) for p in points]
            for start, end in HAND_CONNECTIONS:
                cv2.line(canvas, pixels[start], pixels[end], (70, 220, 120), 2, cv2.LINE_AA)
            for point in pixels:
                cv2.circle(canvas, point, 4, (20, 35, 245), -1, cv2.LINE_AA)
            xs, ys = zip(*pixels)
            cv2.rectangle(canvas, (min(xs), min(ys)), (max(xs), max(ys)), (255, 180, 40), 2)
            label_y = max(24, min(ys) - 10)
            cv2.putText(canvas, hand["handedness"], (min(xs), label_y), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 180, 40), 2, cv2.LINE_AA)

        gesture = recognition["gesture"] if recognition else "No hand detected"
        cv2.rectangle(canvas, (0, h - 82), (w, h), (20, 20, 20), -1)
        cv2.putText(canvas, f"GESTURE: {gesture.upper()}", (20, h - 48), cv2.FONT_HERSHEY_SIMPLEX, 0.85, (80, 240, 130), 2, cv2.LINE_AA)
        cv2.putText(canvas, f"FPS: {fps:.1f}   Reliability: {recognition['reliability'] if recognition else 'Waiting'}", (20, h - 18), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (235, 235, 235), 1, cv2.LINE_AA)
        cv2.putText(canvas, "Press Q to quit", (max(20, w - 190), 30), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2, cv2.LINE_AA)
        cv2.imshow(self.window_name, canvas)

    @staticmethod
    def should_quit(delay_ms=1):
        return (cv2.waitKey(delay_ms) & 0xFF) in (ord("q"), ord("Q"))

    @staticmethod
    def close_all():
        cv2.destroyAllWindows()

