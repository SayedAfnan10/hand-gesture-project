"""Rule-based gesture classification using processed landmark information."""

from modules.gesture_data import FINGER_NAMES, GESTURE_RULES


def recognize_gesture(processed, handedness="Unknown"):
    """Return the single structured result shared by both display windows."""
    states = processed["finger_states"]
    pattern = [int(states[name]) for name in FINGER_NAMES]
    measurements = dict(processed["measurements"])
    pattern_tuple = tuple(pattern)
    gesture = "Unrecognized"
    reasons = []
    rule_steps = ["Read processor finger states", "Build thumb-index-middle-ring-pinky pattern"]

    if pattern_tuple == (1, 1, 1, 1, 1) and measurements["thumb_index_distance_palm_widths"] < 0.32:
        gesture = "OK"
        reasons = ["Thumb is extended", "Index finger is extended", "Thumb and index tips are close relative to palm width", "Middle, ring, and pinky are extended"]
        rule_steps.append("Tip distance < 0.32 palm widths identifies the OK contact")
    elif pattern_tuple == (1, 0, 0, 0, 0):
        offset = measurements["thumb_vertical_offset_palm_heights"]
        if offset > 0.28:
            gesture = "Thumbs Up"
            reasons = ["Thumb is extended", "Other four fingers are folded", "Thumb tip is above the wrist by more than 0.28 palm heights"]
        elif offset < -0.28:
            gesture = "Thumbs Down"
            reasons = ["Thumb is extended", "Other four fingers are folded", "Thumb tip is below the wrist by more than 0.28 palm heights"]
        else:
            reasons = ["Thumb is extended and other fingers are folded", "Thumb direction is too horizontal for up or down"]
        rule_steps.append("Use normalized thumb-to-wrist vertical offset to distinguish up and down")
    else:
        for name, definition in GESTURE_RULES.items():
            if name in ("OK", "Thumbs Up", "Thumbs Down"):
                continue
            if tuple(definition["pattern"]) == pattern_tuple:
                gesture = name
                reasons = [f"{finger.title()} finger {'extended' if states[finger] else 'folded'}" for finger in FINGER_NAMES]
                reasons.append(f"Pattern matches the {name} rule: {definition['condition']}")
                break
        if gesture == "Unrecognized":
            reasons = [f"{finger.title()} finger {'extended' if states[finger] else 'folded'}" for finger in FINGER_NAMES]
            reasons.append("No configured gesture rule matches this pattern and its geometric conditions")

    rule_steps.extend(["Compare against configured gesture patterns", "Apply any gesture-specific geometric condition", f"Select {gesture}"])
    return {
        "gesture": gesture,
        "finger_states": dict(states),
        "pattern": pattern,
        "reasons": reasons,
        "measurements": measurements,
        "handedness": handedness,
        "reliability": "Rule match" if gesture != "Unrecognized" else "No rule match",
        "rule_steps": rule_steps,
    }

