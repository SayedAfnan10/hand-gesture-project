"""Gesture names, finger patterns, and human-readable rule descriptions.

Patterns use the order thumb, index, middle, ring, pinky; 1 means extended.
Some gestures share a finger pattern and are distinguished with geometry.
"""

FINGER_NAMES = ("thumb", "index", "middle", "ring", "pinky")

GESTURE_RULES = {
    "Fist": {"pattern": (0, 0, 0, 0, 0), "condition": "all fingers folded"},
    "Open Palm": {"pattern": (1, 1, 1, 1, 1), "condition": "all fingers extended"},
    "Peace / Victory": {"pattern": (0, 1, 1, 0, 0), "condition": "index and middle extended"},
    "Thumbs Up": {"pattern": (1, 0, 0, 0, 0), "condition": "thumb points above the wrist"},
    "Thumbs Down": {"pattern": (1, 0, 0, 0, 0), "condition": "thumb points below the wrist"},
    "Pointing / Index Finger": {"pattern": (0, 1, 0, 0, 0), "condition": "only index extended"},
    "Three Fingers": {"pattern": (0, 1, 1, 1, 0), "condition": "index, middle, and ring extended"},
    "Four Fingers": {"pattern": (0, 1, 1, 1, 1), "condition": "four fingers extended with thumb folded"},
    "OK": {"pattern": (1, 1, 1, 1, 1), "condition": "thumb and index tips touch while other fingers extend"},
    "Rock": {"pattern": (0, 1, 0, 0, 1), "condition": "index and pinky extended"},
}

