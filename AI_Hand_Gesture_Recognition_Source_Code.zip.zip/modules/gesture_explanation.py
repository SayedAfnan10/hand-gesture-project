"""Second OpenCV window showing the actual recognizer result and evidence."""

import cv2

from modules.gesture_data import FINGER_NAMES


class GestureExplanation:
    def __init__(self, window_name, width, height, x=840, y=40):
        self.window_name = window_name
        self.width = width
        self.height = height
        cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(window_name, width, height)
        cv2.moveWindow(window_name, x, y)

    def render(self, recognition):
        canvas = self._new_canvas()
        lines = []
        if recognition is None:
            lines = [("Show a hand to the camera", (170, 190, 210))]
        else:
            lines.extend([
                (f"GESTURE: {recognition['gesture'].upper()}", (80, 240, 130)),
                (f"Hand: {recognition['handedness']}  |  {recognition['reliability']}", (205, 210, 220)),
                ("FINGER STATUS", (90, 190, 255)),
            ])
            for name in FINGER_NAMES:
                state = "EXTENDED" if recognition["finger_states"][name] else "FOLDED"
                lines.append((f"{name.title():<8}: {state}", (230, 230, 230)))
            lines.extend([
                ("PATTERN  (Thumb Index Middle Ring Pinky)", (90, 190, 255)),
                ("          " + "   ".join(map(str, recognition["pattern"])), (255, 235, 100)),
                ("RECOGNITION ANALYSIS", (90, 190, 255)),
            ])
            lines.extend((f"✓ {reason}", (220, 240, 220)) for reason in recognition["reasons"])
            lines.append(("RULE FLOW", (90, 190, 255)))
            lines.extend((f"{index}. {step}", (195, 205, 215)) for index, step in enumerate(recognition["rule_steps"], 1))
            measurements = recognition["measurements"]
            lines.extend([
                ("RELEVANT MEASUREMENTS", (90, 190, 255)),
                (f"Thumb-index / palm width: {measurements['thumb_index_distance_palm_widths']:.2f}", (195, 205, 215)),
                (f"Thumb vertical / palm height: {measurements['thumb_vertical_offset_palm_heights']:.2f}", (195, 205, 215)),
            ])
        y = 42
        for text, color in lines:
            scale = 0.52 if len(text) > 52 else 0.62
            cv2.putText(canvas, text, (22, y), cv2.FONT_HERSHEY_SIMPLEX, scale, color, 1, cv2.LINE_AA)
            y += 29 if text in ("FINGER STATUS", "RECOGNITION ANALYSIS", "RULE FLOW", "RELEVANT MEASUREMENTS") else 25
        cv2.imshow(self.window_name, canvas)

    def _new_canvas(self):
        canvas = __import__("numpy").full((self.height, self.width, 3), (28, 31, 38), dtype="uint8")
        cv2.putText(canvas, "GESTURE RECOGNITION ANALYSIS", (20, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (245, 245, 245), 2, cv2.LINE_AA)
        return canvas

