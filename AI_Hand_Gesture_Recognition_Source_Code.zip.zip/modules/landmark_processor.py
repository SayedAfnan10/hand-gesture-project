"""Convert 21 landmarks into interpretable finger states and measurements."""

from modules.gesture_data import FINGER_NAMES
from modules.utils import normalized_distance

# MediaPipe's fixed 21-point hand topology.
WRIST = 0
FINGER_JOINTS = {
    "thumb": {"mcp": 2, "pip": 3, "tip": 4},
    "index": {"mcp": 5, "pip": 6, "tip": 8},
    "middle": {"mcp": 9, "pip": 10, "tip": 12},
    "ring": {"mcp": 13, "pip": 14, "tip": 16},
    "pinky": {"mcp": 17, "pip": 18, "tip": 20},
}


def _point(landmarks, index):
    point = landmarks[index]
    if isinstance(point, dict):
        return point
    return {"x": float(point.x), "y": float(point.y), "z": float(point.z)}


def angle_degrees(a, b, c):
    """Angle ABC in degrees, useful for inspecting finger bend."""
    import math
    ba = (a["x"] - b["x"], a["y"] - b["y"])
    bc = (c["x"] - b["x"], c["y"] - b["y"])
    denominator = (ba[0] ** 2 + ba[1] ** 2) ** 0.5 * (bc[0] ** 2 + bc[1] ** 2) ** 0.5
    if denominator == 0:
        return 0.0
    cosine = max(-1.0, min(1.0, (ba[0] * bc[0] + ba[1] * bc[1]) / denominator))
    return math.degrees(math.acos(cosine))


def process_landmarks(landmarks):
    """Return the states and scale-relative measurements used by recognition."""
    if len(landmarks) != 21:
        raise ValueError(f"Expected 21 hand landmarks, received {len(landmarks)}")
    wrist = _point(landmarks, WRIST)
    points = [_point(landmarks, i) for i in range(21)]
    palm_width = max(normalized_distance(points[5], points[17]), 1e-6)
    palm_height = max(normalized_distance(points[0], points[9]), 1e-6)
    states = {}
    tip_positions = {}
    joint_angles = {}
    for name in FINGER_NAMES[1:]:
        joints = FINGER_JOINTS[name]
        tip, pip = points[joints["tip"]], points[joints["pip"]]
        # Wrist radial distance is largely insensitive to image scale and hand tilt.
        states[name] = normalized_distance(tip, wrist) > normalized_distance(pip, wrist) * 1.08
        tip_positions[name] = tip
        joint_angles[name] = angle_degrees(points[joints["mcp"]], pip, tip)

    thumb_tip = points[4]
    thumb_ip = points[3]
    # Thumb abduction: tip must be measurably farther from the index MCP than IP is.
    states["thumb"] = normalized_distance(thumb_tip, points[5]) > normalized_distance(thumb_ip, points[5]) * 1.12
    # Keep the public order stable (thumb, index, middle, ring, pinky).
    states = {name: bool(states[name]) for name in FINGER_NAMES}
    tip_positions["thumb"] = thumb_tip
    thumb_index_distance = normalized_distance(thumb_tip, points[8])
    return {
        "finger_states": states,
        "pattern": [int(states[name]) for name in FINGER_NAMES],
        "tip_positions": tip_positions,
        "measurements": {
            "palm_width_norm": palm_width,
            "palm_height_norm": palm_height,
            "thumb_index_distance_norm": thumb_index_distance,
            "thumb_index_distance_palm_widths": thumb_index_distance / palm_width,
            "thumb_vertical_offset_palm_heights": (wrist["y"] - thumb_tip["y"]) / palm_height,
            "index_middle_distance_norm": normalized_distance(points[8], points[12]),
            "finger_joint_angles_deg": joint_angles,
        },
        "landmarks": points,
    }

